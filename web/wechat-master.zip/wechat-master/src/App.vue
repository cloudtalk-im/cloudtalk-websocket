<template>
  <router-view>
    
  </router-view>
</template>

<script>
import index from './component/index.vue'

export default {
  data () {
    return {
    }
  },
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  width: 860px;height: 575px;background-color: white;margin: 16px auto;
  overflow: hidden;
}


</style>
