# 微信PC版Demo

> 模仿微信PC版制作的Demo

## 详细描述

### 使用方法

	npm install
	npm run dev

### 版本信息

- 2017-06-20 第一版 <br/> 实现静态页面
- 2017-07-11 第二版 <br/> 使用websocket实现实时聊天的功能 <br/> 服务端的代码可以看[这里](https://github.com/j20041426/wechat-server)


### todo：
- 新消息提示效果(小圆点)
- 群聊功能